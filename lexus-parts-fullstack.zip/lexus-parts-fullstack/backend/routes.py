import csv
import io
import json
import os
import sqlite3
from flask import Blueprint, current_app, jsonify, request, session, Response
from werkzeug.security import generate_password_hash, check_password_hash

from .db import get_db
from .notify import notify_new_registration
from .security import rate_limit, require_admin, require_json
from .validators import validate_registration

api = Blueprint("api", __name__, url_prefix="/api")

# A throw-away hash so login takes the same time whether or not the e-mail exists.
_DUMMY_HASH = generate_password_hash("not-a-real-password")


def _public_user(row):
    return {
        "id": row["id"],
        "firstName": row["first_name"],
        "lastName": row["last_name"],
        "email": row["email"],
        "carModel": row["car_model"],
        "carYear": row["car_year"],
        "createdAt": row["created_at"],
    }


def _admin_user(row):
    """Everything except the password hash."""
    return {
        "id": row["id"], "firstName": row["first_name"], "lastName": row["last_name"],
        "email": row["email"], "phone": row["phone"], "dob": row["dob"], "gender": row["gender"],
        "carModel": row["car_model"], "carYear": row["car_year"], "vin": row["vin"],
        "mileage": row["mileage"], "address": row["address"], "city": row["city"],
        "state": row["state"], "zip": row["zip"], "country": row["country"],
        "newsletter": bool(row["newsletter"]), "createdAt": row["created_at"],
    }


# ---------------------------------------------------------------- health
@api.get("/health")
def health():
    try:
        get_db().execute("SELECT 1").fetchone()
        return jsonify(ok=True, status="healthy")
    except sqlite3.Error:
        return jsonify(ok=False, status="database unavailable"), 503


# ---------------------------------------------------------------- registration / auth
@api.post("/register")
@rate_limit("RATE_LIMIT_REGISTER", "register")
@require_json
def register():
    data = request.get_json()
    clean, errors = validate_registration(data)
    if errors:
        return jsonify(ok=False, message="Please correct the highlighted details.", errors=errors), 422

    db = get_db()
    try:
        cur = db.execute(
            """INSERT INTO users
               (first_name, last_name, email, phone, dob, gender, car_model, car_year, vin,
                mileage, address, city, state, zip, country, password_hash,
                newsletter, agreed_rules, agreed_terms)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (clean["firstName"], clean["lastName"], clean["email"], clean["phone"], clean["dob"],
             clean["gender"], clean["carModel"], clean["carYear"], clean["vin"] or None,
             clean["mileage"] or None, clean["address"], clean["city"], clean["state"],
             clean["zip"], clean["country"], generate_password_hash(clean["password"]),
             int(clean["newsletter"]), int(clean["agreeRules"]), int(clean["agreeTerms"])),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify(ok=False, message="This email is already registered.",
                       errors={"email": "This email is already registered."}), 409

    notify_new_registration(current_app, clean)
    return jsonify(ok=True, message="Registration successful.", id=cur.lastrowid), 201


@api.post("/login")
@rate_limit("RATE_LIMIT_LOGIN", "login")
@require_json
def login():
    data = request.get_json()
    email = str(data.get("email", "")).strip().lower()
    password = data.get("password")
    password = password if isinstance(password, str) else ""

    row = get_db().execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
    valid = check_password_hash(row["password_hash"] if row else _DUMMY_HASH, password)
    if not (row and valid):
        return jsonify(ok=False, message="Invalid email or password."), 401

    session.clear()
    session.permanent = True
    session["user_id"] = row["id"]
    return jsonify(ok=True, user=_public_user(row))


@api.post("/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@api.get("/me")
def me():
    uid = session.get("user_id")
    row = get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone() if uid else None
    if not row:
        return jsonify(ok=False, message="Not logged in."), 401
    return jsonify(ok=True, user=_public_user(row))


# ---------------------------------------------------------------- catalog (read-only)
def _catalog():
    cache = current_app.extensions.setdefault("catalog_cache", {})
    if "data" not in cache:
        path = os.path.join(current_app.root_path, "data", "catalog.json")
        with open(path, encoding="utf-8") as fh:
            cache["data"] = json.load(fh)
    return cache["data"]


def _list_items(kind):
    items = _catalog()[kind]
    q = request.args.get("q", "").strip().lower()
    if q:
        items = [i for i in items if q in i.get("title", "").lower()
                 or q in i.get("description", "").lower()]
    return jsonify(ok=True, count=len(items), items=items)


def _one_item(kind, item_id):
    for item in _catalog()[kind]:
        if item["id"] == item_id:
            return jsonify(ok=True, item=item)
    return jsonify(ok=False, message="Not found."), 404


@api.get("/products")
def products():
    return _list_items("products")


@api.get("/products/<int:item_id>")
def product(item_id):
    return _one_item("products", item_id)


@api.get("/tools")
def tools():
    return _list_items("tools")


@api.get("/tools/<int:item_id>")
def tool(item_id):
    return _one_item("tools", item_id)


# ---------------------------------------------------------------- admin (X-Admin-Key header)
@api.get("/admin/registrations")
@require_admin
def admin_registrations():
    try:
        limit = max(1, min(int(request.args.get("limit", 100)), 500))
        offset = max(0, int(request.args.get("offset", 0)))
    except ValueError:
        return jsonify(ok=False, message="limit/offset must be numbers."), 400
    db = get_db()
    total = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    rows = db.execute("SELECT * FROM users ORDER BY id DESC LIMIT ? OFFSET ?", (limit, offset)).fetchall()
    return jsonify(ok=True, total=total, items=[_admin_user(r) for r in rows])


def _csv_safe(value):
    """Stop spreadsheet formula injection (=, +, -, @ at the start of a cell)."""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") else text


@api.get("/admin/registrations.csv")
@require_admin
def admin_registrations_csv():
    rows = get_db().execute("SELECT * FROM users ORDER BY id DESC").fetchall()
    buf = io.StringIO()
    writer = csv.writer(buf)
    fields = ["id", "firstName", "lastName", "email", "phone", "dob", "gender", "carModel", "carYear",
              "vin", "mileage", "address", "city", "state", "zip", "country", "newsletter", "createdAt"]
    writer.writerow(fields)
    for r in rows:
        u = _admin_user(r)
        writer.writerow([_csv_safe(u[f]) for f in fields])
    return Response(buf.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=registrations.csv"})


@api.delete("/admin/registrations/<int:user_id>")
@require_admin
def admin_delete_registration(user_id):
    db = get_db()
    cur = db.execute("DELETE FROM users WHERE id = ?", (user_id,))
    db.commit()
    if cur.rowcount == 0:
        return jsonify(ok=False, message="Not found."), 404
    return jsonify(ok=True)
