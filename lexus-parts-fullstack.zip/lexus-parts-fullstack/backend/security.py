"""Rate limiting, CORS, security headers, admin auth."""
import hmac
import time
import threading
from collections import defaultdict, deque
from functools import wraps
from flask import request, jsonify, current_app


class RateLimiter:
    """Tiny in-memory sliding-window limiter.

    Works per process, so run a single gunicorn worker (the provided Procfile does)
    or swap this for Redis if you scale out.
    """

    def __init__(self):
        self._hits = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, key, limit, window):
        now = time.monotonic()
        with self._lock:
            q = self._hits[key]
            while q and now - q[0] > window:
                q.popleft()
            if len(q) >= limit:
                return False, int(window - (now - q[0])) + 1
            q.append(now)
            if len(self._hits) > 10000:  # keep memory bounded
                for k in [k for k, v in self._hits.items() if not v]:
                    self._hits.pop(k, None)
            return True, 0

    def reset(self):
        with self._lock:
            self._hits.clear()


limiter = RateLimiter()


def _parse(spec):
    count, window = spec.split("/")
    return int(count), int(window)


def rate_limit(config_key, bucket):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            limit, window = _parse(current_app.config[config_key])
            ok, retry = limiter.allow(f"{bucket}:{request.remote_addr}", limit, window)
            if not ok:
                resp = jsonify(ok=False, message="Too many requests. Please try again later.")
                resp.status_code = 429
                resp.headers["Retry-After"] = str(retry)
                return resp
            return fn(*args, **kwargs)
        return wrapper
    return decorator


def require_json(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not request.is_json:
            return jsonify(ok=False, message="Content-Type must be application/json."), 415
        if not isinstance(request.get_json(silent=True), dict):
            return jsonify(ok=False, message="Request body must be a JSON object."), 400
        return fn(*args, **kwargs)
    return wrapper


def require_admin(fn):
    @wraps(fn)
    @rate_limit("RATE_LIMIT_ADMIN", "admin")
    def wrapper(*args, **kwargs):
        expected = current_app.config["ADMIN_API_KEY"]
        if not expected:
            return jsonify(ok=False, message="Admin access is not configured."), 404
        supplied = request.headers.get("X-Admin-Key", "")
        if not hmac.compare_digest(supplied.encode(), expected.encode()):
            return jsonify(ok=False, message="Unauthorized."), 401
        return fn(*args, **kwargs)
    return wrapper


def register_hooks(app):
    @app.after_request
    def add_headers(resp):
        # Security headers
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        resp.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if app.config["IS_PRODUCTION"]:
            resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

        # CORS (only for explicitly allowed origins)
        origin = request.headers.get("Origin")
        if origin and origin.rstrip("/") in app.config["ALLOWED_ORIGINS"]:
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Vary"] = "Origin"
            resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Accept"
            resp.headers["Access-Control-Max-Age"] = "600"

        # Caching: API never cached; html/js/css revalidate; media cached for a day
        path = request.path
        if path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        elif resp.status_code == 200 and "Cache-Control" not in resp.headers:
            if path == "/" or path.endswith((".html", ".js", ".css")):
                resp.headers["Cache-Control"] = "no-cache"
            else:
                resp.headers["Cache-Control"] = "public, max-age=86400"
        if path.startswith("/admin"):
            resp.headers["X-Robots-Tag"] = "noindex, nofollow"
        return resp

    @app.before_request
    def handle_preflight():
        if request.method == "OPTIONS" and request.path.startswith("/api/"):
            from flask import make_response
            return make_response("", 204)
