"""Server-side validation. Never trust the browser - the HTML `required` attributes
can be bypassed by anyone who calls the API directly."""
import re
from datetime import date, datetime

# These lists mirror the <select>/<radio> options in public/index.html
GENDERS = {"Male", "Female", "Other"}
CAR_MODELS = {"Lexus IS300", "Lexus IS200", "Toyota Altezza", "Other"}
CAR_YEARS = {"2001", "2002", "2003", "2004", "2005", "Other"}
COUNTRIES = {"USA", "Canada", "UK", "Australia", "Germany", "France", "Japan",
             "UAE", "Saudi Arabia", "Pakistan", "India", "Other"}

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
VIN_RE = re.compile(r"^[A-Za-z0-9]{1,17}$")
CONTROL_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _clean(value, max_len):
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    value = CONTROL_RE.sub("", value).strip()
    return value[:max_len + 1]  # +1 so over-long input is detected, not silently cut


def validate_registration(data):
    """Return (clean_dict, errors_dict)."""
    errors = {}
    clean = {}

    def text(key, label, max_len, required=True):
        val = _clean(data.get(key), max_len)
        if required and not val:
            errors[key] = f"{label} is required."
        elif len(val) > max_len:
            errors[key] = f"{label} must be at most {max_len} characters."
        clean[key] = val
        return val

    text("firstName", "First name", 60)
    text("lastName", "Last name", 60)

    email = text("email", "Email", 254).lower()
    if email and "email" not in errors and not EMAIL_RE.match(email):
        errors["email"] = "Please enter a valid email address."
    clean["email"] = email

    phone = text("phone", "Phone", 30)
    if phone and "phone" not in errors:
        digits = re.sub(r"\D", "", phone)
        if not re.fullmatch(r"[0-9+()\-.\s]+", phone) or not 7 <= len(digits) <= 15:
            errors["phone"] = "Please enter a valid phone number (7-15 digits)."

    dob = text("dob", "Date of birth", 10)
    if dob and "dob" not in errors:
        try:
            parsed = datetime.strptime(dob, "%Y-%m-%d").date()
            if parsed >= date.today() or parsed.year < 1900:
                errors["dob"] = "Please enter a valid date of birth."
        except ValueError:
            errors["dob"] = "Date of birth must be in YYYY-MM-DD format."

    def choice(key, label, allowed):
        val = _clean(data.get(key), 40)
        if not val:
            errors[key] = f"{label} is required."
        elif val not in allowed:
            errors[key] = f"Invalid {label.lower()}."
        clean[key] = val

    choice("gender", "Gender", GENDERS)
    choice("carModel", "Car model", CAR_MODELS)
    choice("carYear", "Car year", CAR_YEARS)
    choice("country", "Country", COUNTRIES)

    vin = text("vin", "VIN", 17, required=False)
    if vin and "vin" not in errors and not VIN_RE.match(vin):
        errors["vin"] = "VIN may contain only letters and numbers (max 17)."
    text("mileage", "Mileage", 40, required=False)

    text("address", "Address", 200)
    text("city", "City", 80)
    text("state", "State", 80)
    text("zip", "ZIP code", 20)

    password = data.get("password")
    if not isinstance(password, str) or len(password) < 8:
        errors["password"] = "Password must be at least 8 characters."
    elif len(password) > 128:
        errors["password"] = "Password must be at most 128 characters."
    clean["password"] = password if isinstance(password, str) else ""

    for key, label in (("agreeRules", "the Rules & Regulations"), ("agreeTerms", "the Terms & Conditions")):
        if data.get(key) is not True:
            errors[key] = f"You must agree to {label}."
        clean[key] = data.get(key) is True
    clean["newsletter"] = data.get("newsletter") is True

    return clean, errors
