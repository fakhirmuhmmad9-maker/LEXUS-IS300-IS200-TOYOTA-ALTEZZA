"""Central configuration, read from environment variables (see .env.example)."""
import os
import secrets
import logging

log = logging.getLogger(__name__)


def _bool(name, default=False):
    return os.environ.get(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _list(name):
    raw = os.environ.get(name, "")
    return [item.strip().rstrip("/") for item in raw.split(",") if item.strip()]


class Config:
    ENVIRONMENT = os.environ.get("ENVIRONMENT", "development").lower()
    IS_PRODUCTION = ENVIRONMENT == "production"

    SECRET_KEY = os.environ.get("SECRET_KEY") or ""
    DATABASE_PATH = os.environ.get("DATABASE_PATH", os.path.join("instance", "app.db"))

    # Origins allowed to call the API from a *different* site (CORS).
    # Leave empty when the backend serves the frontend itself (recommended).
    ALLOWED_ORIGINS = _list("ALLOWED_ORIGINS")

    # Needed to read the admin panel / export registrations. Empty = admin disabled.
    ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "")

    # Set to 1 when running behind a proxy such as Render/Heroku/Nginx so the real
    # client IP (for rate limiting) is read from X-Forwarded-For.
    TRUST_PROXY = _bool("TRUST_PROXY", False)

    # Rate limits: "<max requests>/<window seconds>"
    RATE_LIMIT_REGISTER = os.environ.get("RATE_LIMIT_REGISTER", "5/3600")
    RATE_LIMIT_LOGIN = os.environ.get("RATE_LIMIT_LOGIN", "10/900")
    RATE_LIMIT_ADMIN = os.environ.get("RATE_LIMIT_ADMIN", "30/300")

    # Optional e-mail notification on every new registration (plain SMTP).
    SMTP_HOST = os.environ.get("SMTP_HOST", "")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
    SMTP_USER = os.environ.get("SMTP_USER", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
    SMTP_FROM = os.environ.get("SMTP_FROM", "") or SMTP_USER
    NOTIFY_EMAIL = os.environ.get("NOTIFY_EMAIL", "")

    MAX_CONTENT_LENGTH = 64 * 1024  # requests here are small JSON bodies
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = IS_PRODUCTION
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 24 * 7  # 7 days

    @classmethod
    def finalize(cls):
        if not cls.SECRET_KEY:
            if cls.IS_PRODUCTION:
                raise RuntimeError(
                    "SECRET_KEY is not set. Set it in your hosting environment variables "
                    "(generate one with: python -c \"import secrets; print(secrets.token_hex(32))\")."
                )
            cls.SECRET_KEY = secrets.token_hex(32)
            log.warning("SECRET_KEY not set - using a temporary one (sessions reset on restart).")
