"""Optional e-mail notification (plain SMTP, stdlib only). Silent no-op if not configured."""
import logging
import smtplib
import threading
from email.message import EmailMessage

log = logging.getLogger(__name__)


def _send(cfg, subject, body):
    try:
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = cfg["SMTP_FROM"]
        msg["To"] = cfg["NOTIFY_EMAIL"]
        msg.set_content(body)
        with smtplib.SMTP(cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=15) as smtp:
            smtp.starttls()
            if cfg["SMTP_USER"]:
                smtp.login(cfg["SMTP_USER"], cfg["SMTP_PASSWORD"])
            smtp.send_message(msg)
    except Exception:  # never let a mail problem break registration
        log.exception("Could not send notification e-mail")


def notify_new_registration(app, user):
    cfg = {k: app.config[k] for k in
           ("SMTP_HOST", "SMTP_PORT", "SMTP_USER", "SMTP_PASSWORD", "SMTP_FROM", "NOTIFY_EMAIL")}
    if not (cfg["SMTP_HOST"] and cfg["NOTIFY_EMAIL"] and cfg["SMTP_FROM"]):
        return
    body = (
        "NEW CUSTOMER REGISTRATION\n\n"
        f"Name: {user['firstName']} {user['lastName']}\n"
        f"Email: {user['email']}\n"
        f"Phone: {user['phone']}\n"
        f"DOB: {user['dob']}\n"
        f"Gender: {user['gender']}\n\n"
        f"Car: {user['carModel']} ({user['carYear']})\n"
        f"VIN: {user['vin'] or 'N/A'}\n"
        f"Mileage: {user['mileage'] or 'N/A'}\n\n"
        f"Address: {user['address']}\n"
        f"City: {user['city']}, {user['state']} {user['zip']}\n"
        f"Country: {user['country']}\n"
        f"Newsletter: {'yes' if user['newsletter'] else 'no'}\n"
    )
    threading.Thread(
        target=_send, args=(cfg, f"New Registration - {user['firstName']} {user['lastName']}", body),
        daemon=True,
    ).start()
