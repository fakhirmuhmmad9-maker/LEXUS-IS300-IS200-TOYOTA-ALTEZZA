# Lexus IS300 / Altezza Parts Store — Full-Stack (Flask + SQLite)

Aapka existing frontend (`public/`) ab ek Flask backend ke saath jud gaya hai.
Ek hi server frontend bhi serve karta hai aur API bhi, is liye **CORS ka masla hi nahi aata**.

## Kya kya hai

| Cheez | Detail |
|---|---|
| Backend | Python 3.12 + Flask, `gunicorn` se production mein |
| Database | SQLite (`instance/app.db`, pehli baar chalne par khud ban jata hai) |
| Frontend | `public/index.html`, `index.css`, `index.js` + images (aapka original design, sirf registration form API se jura hai) |
| Admin panel | `/admin` — registrations dekhein, CSV download karein, delete karein |

### Pehle aur ab

Pehle registration form `mailto:` aur WhatsApp kholta tha (data kahin save nahi hota tha, aur password bhi nahi).
Ab form `POST /api/register` ko call karta hai: data validate hota hai, password **hash** hokar database mein save hota hai, aur (optional) aapko e-mail notification milti hai.
Automatic `mailto:` / WhatsApp khulna band kar diya gaya hai. Contact buttons (WhatsApp / email links) waise hi kaam karte hain.

## API endpoints

| Method | URL | Kaam |
|---|---|---|
| GET | `/api/health` | Server + database check |
| POST | `/api/register` | Naya customer register (JSON body, form ke fields) |
| POST | `/api/login` | Email + password se login (session cookie) |
| GET | `/api/me` | Logged-in user ki info |
| POST | `/api/logout` | Logout |
| GET | `/api/products`, `/api/products/<id>` | 15 car-listing cards ka data |
| GET | `/api/tools`, `/api/tools/<id>` | 80 parts ka data (`?q=wheel` se search) |
| GET | `/api/admin/registrations` | Registrations list (header `X-Admin-Key` zaroori) |
| GET | `/api/admin/registrations.csv` | CSV export (admin key) |
| DELETE | `/api/admin/registrations/<id>` | Registration delete (admin key) |

> Products/tools abhi bhi frontend ke andar ke data se dikhte hain (design touch nahi kiya). API unka ready-made backup/future use hai (`data/catalog.json`).

## Security jo lagi hui hai

- Passwords hashed (scrypt), plain text kabhi save nahi hota
- Server-side validation (email, phone, DOB, VIN, dropdown values, password length)
- SQL injection se bachao (parameterized queries)
- Rate limiting: register 5/ghanta, login 10/15 min, admin 30/5 min (per IP)
- CORS sirf `ALLOWED_ORIGINS` wali sites ke liye
- Security headers, JSON-only API, request size limit (64 KB)
- Admin endpoints sirf `ADMIN_API_KEY` se; CSV export mein spreadsheet formula-injection guard

---

## 1) Local machine par chalana

Python 3.10+ chahiye.

```bash
cd lexus-parts-fullstack

# virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

pip install -r requirements.txt

# settings file
cp .env.example .env               # Windows: copy .env.example .env
# .env kholein aur ADMIN_API_KEY mein koi lamba random password likh dein

python app.py
```

Browser mein kholein: <http://127.0.0.1:5000>
Admin panel: <http://127.0.0.1:5000/admin> (wohi `ADMIN_API_KEY` dalein)

Tests chalane ke liye (koi extra package nahi chahiye):

```bash
python -m unittest discover -s tests -v
```

## 2) GitHub par push karna

```bash
git init
git add .
git commit -m "Lexus parts store: Flask backend + frontend"
git branch -M main
git remote add origin https://github.com/<aapka-username>/<repo-name>.git
git push -u origin main
```

`.env` aur `instance/` (database) `.gitignore` mein hain, GitHub par nahi jayenge. Secrets kabhi commit na karein.

## 3) Live deploy — Render (recommended)

Flask + SQLite jaisi **hamesha chalne wali** app ke liye Render sahi hai. (Vercel/Netlify serverless hain, wahan SQLite file save nahi rehti, is liye is project ke liye unhe use na karein.)

1. <https://render.com> par GitHub se sign in karein.
2. **New +** → **Blueprint** → apna repo select karein. Render `render.yaml` padh leta hai.
   (Ya **New +** → **Web Service**: Build Command `pip install -r requirements.txt`, Start Command `gunicorn app:app --workers 1 --threads 4 --timeout 60`.)
3. Environment variables:
   - `ENVIRONMENT` = `production`
   - `SECRET_KEY` = lamba random text (`python -c "import secrets; print(secrets.token_hex(32))"`); Blueprint ise khud bana deta hai
   - `ADMIN_API_KEY` = aapka admin password
   - `TRUST_PROXY` = `1`
4. **Deploy** dabayein. Kuch minute mein `https://<naam>.onrender.com` live hoga. `/api/health` kholkar check karein.

### Zaroori: database ka data kaise bachayein

Render ke **free plan** par file system **temporary** hota hai: restart ya redeploy par `app.db` (registrations) mit jata hai, aur free service 15 min inactivity par so bhi jati hai (pehli request thori slow).
Registrations hamesha ke liye rakhne ke liye:

- **Render paid plan + Disk**: `render.yaml` mein `disk:` wala hissa uncomment karein aur env var `DATABASE_PATH=/var/data/app.db` set karein; **ya**
- Regular tor par `/admin` se **Download CSV** karke backup lete rahein (free plan par kam az kam yeh karein).

Agar baad mein bohat traffic ho to PostgreSQL par move karna behtar hoga (SQLite chhoti site ke liye theek hai).

### Optional: registration par e-mail milna

Env vars set karein: `SMTP_HOST`, `SMTP_PORT` (587), `SMTP_USER`, `SMTP_PASSWORD`, `SMTP_FROM`, `NOTIFY_EMAIL`.
Gmail ke liye: 2-Step Verification on karke **App Password** banayein (normal Gmail password nahi chalega).
Yeh set na hon to e-mail simply skip hoti hai, registration phir bhi save hoti hai.

## 4) Frontend alag jagah host karna (optional)

Agar frontend Netlify/Vercel par aur backend Render par ho:

1. `public/index.html` ke `<head>` mein yeh line dalein:
   `<meta name="api-base" content="https://<naam>.onrender.com">`
2. Render par `ALLOWED_ORIGINS=https://aapki-site.netlify.app` set karein (trailing slash ke baghair).

Registration is tarah bhi chalegi. (Login/session cookie wala flow same-site hosting ke liye bana hai, is liye simplest raasta ek hi Render service rakhna hai.)

## Project structure

```
app.py                  # Flask app (frontend + API)
backend/                # config, db, validators, security, routes, notify
public/                 # frontend: index.html, index.css, index.js, admin.html, images
data/catalog.json       # products + tools data (API ke liye)
tests/test_api.py       # 17 automated tests
requirements.txt  Procfile  render.yaml  .env.example  .gitignore
```

## Aam masail

- **Register par "Too many requests"**: rate limit; thori der baad try karein (`RATE_LIMIT_REGISTER` se badal sakte hain).
- **Deploy par "SECRET_KEY is not set"**: Render env vars mein `SECRET_KEY` add karein.
- **`/admin` par "not enabled"**: `ADMIN_API_KEY` set nahi hai.
- **Console mein `script.js`, `fakhir1.js`, `fakhirpopup.js`, `popup-fix.js` 404**: yeh 4 files aapke original zip mein thi hi nahi, magar `index.html` unhe load karne ki koshish karta hai. Site in ke baghair chal rahi hai; agar yeh aapke paas hain to `public/` mein rakh dein.
