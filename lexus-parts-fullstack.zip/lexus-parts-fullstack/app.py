"""Lexus IS300 / Altezza parts store - Flask backend + static frontend.

Run locally:   python app.py
Production:    gunicorn app:app   (see Procfile / render.yaml)
"""
import logging
import os

try:  # load variables from a local .env file if python-dotenv is installed
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from flask import Flask, jsonify, request, send_from_directory
from werkzeug.middleware.proxy_fix import ProxyFix

from backend.config import Config
from backend.db import init_db
from backend.routes import api
from backend.security import register_hooks

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")


def create_app(overrides=None):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    Config.finalize()

    app = Flask(__name__, static_folder=PUBLIC_DIR, static_url_path="")
    app.config.from_object(Config)
    if overrides:
        app.config.update(overrides)

    if app.config["TRUST_PROXY"]:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

    init_db(app)
    register_hooks(app)
    app.register_blueprint(api)

    @app.get("/")
    def index():
        return send_from_directory(PUBLIC_DIR, "index.html")

    @app.get("/admin")
    def admin_page():
        return send_from_directory(PUBLIC_DIR, "admin.html")

    @app.errorhandler(404)
    def not_found(_e):
        if request.path.startswith("/api/"):
            return jsonify(ok=False, message="Not found."), 404
        return "Not found", 404

    @app.errorhandler(405)
    def method_not_allowed(_e):
        return jsonify(ok=False, message="Method not allowed."), 405

    @app.errorhandler(413)
    def too_large(_e):
        return jsonify(ok=False, message="Request too large."), 413

    @app.errorhandler(500)
    def server_error(_e):
        return jsonify(ok=False, message="Something went wrong on our side. Please try again."), 500

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=not Config.IS_PRODUCTION)
