"""Run with:  python -m unittest discover -s tests -v   (no extra packages needed)"""
import os
import sqlite3
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "import.db")
os.environ["ENVIRONMENT"] = "development"

from app import create_app  # noqa: E402
from backend.security import limiter  # noqa: E402

GOOD = {
    "firstName": "John", "lastName": "Smith", "email": "John@Example.com", "phone": "+1 281 409 3718",
    "dob": "1990-05-17", "gender": "Male", "carModel": "Lexus IS300", "carYear": "2002",
    "vin": "JT8BD69S123456789", "mileage": "120,000 miles", "address": "123 Main Street",
    "city": "Tacoma", "state": "WA", "zip": "98444", "country": "USA",
    "password": "correct horse battery", "agreeRules": True, "agreeTerms": True, "newsletter": True,
}
ADMIN = {"X-Admin-Key": "admin-secret"}


class Base(unittest.TestCase):
    def setUp(self):
        limiter.reset()
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "test.db")
        self.app = create_app({
            "TESTING": True, "DATABASE_PATH": self.db_path, "ADMIN_API_KEY": "admin-secret",
            "ALLOWED_ORIGINS": ["https://shop.example.com"],
        })
        self.client = self.app.test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def post(self, path, body, **kw):
        return self.client.post(path, json=body, **kw)

    def count_users(self):
        con = sqlite3.connect(self.db_path)
        try:
            return con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        finally:
            con.close()


class FrontendTests(Base):
    def test_frontend_and_assets_served(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"Lexus", r.data)
        for path in ("/index.css", "/index.js", "/admin"):
            self.assertEqual(self.client.get(path).status_code, 200, path)
        # missing scripts must 404, not fall back to HTML (which would be a JS syntax error)
        self.assertEqual(self.client.get("/does-not-exist.js").status_code, 404)

    def test_frontend_posts_to_api(self):
        html = self.client.get("/").get_data(as_text=True)
        self.assertIn("/api/register", html)
        self.assertNotIn("window.location.href = 'mailto:' + CONFIG.email + '?subject=' + encodeURIComponent(emailSubject)", html.split("function handleRegistration")[1].split("GLOBAL EVENT")[0])

    def test_health_and_headers(self):
        r = self.client.get("/api/health")
        self.assertTrue(r.get_json()["ok"])
        self.assertEqual(r.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(r.headers["Cache-Control"], "no-store")


class RegistrationTests(Base):
    def test_success_and_password_hashed(self):
        r = self.post("/api/register", GOOD)
        self.assertEqual(r.status_code, 201)
        con = sqlite3.connect(self.db_path)
        email, pw, news = con.execute("SELECT email, password_hash, newsletter FROM users").fetchone()
        con.close()
        self.assertEqual(email, "john@example.com")
        self.assertNotEqual(pw, GOOD["password"])
        self.assertTrue(pw.startswith(("scrypt:", "pbkdf2:")))
        self.assertEqual(news, 1)

    def test_duplicate_email_case_insensitive(self):
        self.assertEqual(self.post("/api/register", GOOD).status_code, 201)
        r = self.post("/api/register", {**GOOD, "email": "JOHN@example.COM"})
        self.assertEqual(r.status_code, 409)
        self.assertIn("email", r.get_json()["errors"])

    def test_validation_errors(self):
        cases = [
            ("email", "not-an-email"), ("phone", "abc"), ("dob", "2999-01-01"), ("dob", "17/05/1990"),
            ("gender", "Robot"), ("carModel", "Honda"), ("country", "Narnia"), ("vin", "BAD VIN!!"),
            ("password", "short"), ("firstName", ""), ("firstName", "x" * 100),
            ("agreeTerms", False), ("agreeRules", "true"),
        ]
        for field, value in cases:
            with self.subTest(field=field, value=value):
                limiter.reset()
                r = self.post("/api/register", {**GOOD, field: value})
                self.assertEqual(r.status_code, 422)
                self.assertIn(field, r.get_json()["errors"])
        self.assertEqual(self.count_users(), 0)

    def test_optional_fields_can_be_empty(self):
        r = self.post("/api/register", {**GOOD, "vin": "", "mileage": "", "newsletter": False})
        self.assertEqual(r.status_code, 201)

    def test_rejects_non_json_and_non_object(self):
        self.assertEqual(self.client.post("/api/register", data="a=b").status_code, 415)
        self.assertEqual(self.client.post("/api/register", json=["x"]).status_code, 400)

    def test_sql_injection_is_inert(self):
        r = self.post("/api/register", {**GOOD, "firstName": "Robert'); DROP TABLE users;--"})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(self.count_users(), 1)

    def test_rate_limit(self):
        codes = [self.post("/api/register", {**GOOD, "email": f"u{i}@example.com"}).status_code for i in range(7)]
        self.assertEqual(codes, [201] * 5 + [429, 429])


class AuthTests(Base):
    def test_login_me_logout(self):
        self.post("/api/register", GOOD)
        self.assertEqual(self.post("/api/login", {"email": GOOD["email"], "password": "wrong-password"}).status_code, 401)
        self.assertEqual(self.post("/api/login", {"email": "nobody@example.com", "password": "x"}).status_code, 401)
        r = self.post("/api/login", {"email": "JOHN@example.com", "password": GOOD["password"]})
        self.assertEqual(r.status_code, 200)
        self.assertNotIn("password", str(r.get_json()).lower())
        me = self.client.get("/api/me")
        self.assertEqual(me.get_json()["user"]["email"], "john@example.com")
        self.client.post("/api/logout")
        self.assertEqual(self.client.get("/api/me").status_code, 401)


class CorsTests(Base):
    def test_allowlist(self):
        ok = self.client.options("/api/register", headers={"Origin": "https://shop.example.com"})
        self.assertEqual(ok.status_code, 204)
        self.assertEqual(ok.headers["Access-Control-Allow-Origin"], "https://shop.example.com")
        bad = self.client.options("/api/register", headers={"Origin": "https://evil.example.com"})
        self.assertNotIn("Access-Control-Allow-Origin", bad.headers)


class AdminTests(Base):
    def test_requires_key(self):
        self.post("/api/register", GOOD)
        self.assertEqual(self.client.get("/api/admin/registrations").status_code, 401)
        self.assertEqual(self.client.get("/api/admin/registrations", headers={"X-Admin-Key": "nope"}).status_code, 401)
        r = self.client.get("/api/admin/registrations", headers=ADMIN)
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json()["total"], 1)
        self.assertNotIn("password", str(r.get_json()).lower())

    def test_disabled_without_key(self):
        limiter.reset()
        a = create_app({"TESTING": True, "DATABASE_PATH": os.path.join(self.tmp.name, "x.db"), "ADMIN_API_KEY": ""})
        self.assertEqual(a.test_client().get("/api/admin/registrations", headers={"X-Admin-Key": ""}).status_code, 404)

    def test_csv_formula_injection_guard(self):
        self.post("/api/register", {**GOOD, "firstName": '=HYPERLINK("http://x")'})
        r = self.client.get("/api/admin/registrations.csv", headers=ADMIN)
        self.assertEqual(r.mimetype, "text/csv")
        self.assertIn("'=HYPERLINK", r.get_data(as_text=True))

    def test_delete(self):
        uid = self.post("/api/register", GOOD).get_json()["id"]
        self.assertEqual(self.client.delete(f"/api/admin/registrations/{uid}", headers=ADMIN).status_code, 200)
        self.assertEqual(self.client.delete(f"/api/admin/registrations/{uid}", headers=ADMIN).status_code, 404)


class CatalogTests(Base):
    def test_catalog(self):
        self.assertEqual(self.client.get("/api/products").get_json()["count"], 15)
        self.assertTrue(self.client.get("/api/products/1").get_json()["item"]["title"].startswith("Lexus IS300"))
        self.assertEqual(self.client.get("/api/products/999").status_code, 404)
        self.assertEqual(self.client.get("/api/tools").get_json()["count"], 80)
        hits = self.client.get("/api/tools?q=wheel").get_json()["items"]
        self.assertTrue(hits)
        self.assertTrue(all("wheel" in (i["title"] + i["description"]).lower() for i in hits))
        self.assertFalse(self.client.get("/api/nope").get_json()["ok"])


if __name__ == "__main__":
    unittest.main()
